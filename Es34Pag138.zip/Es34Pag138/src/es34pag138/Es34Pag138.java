package es34pag138;

import java.io.*;
import java.time.*;
import java.util.*;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/*
 * @author NICHOLASGHERBI
 */
public class Es34Pag138 {
    /*
    private final List<Veicolo> veicoli;

        public Es34Pag138() {
            veicoli = new ArrayList<Veicolo>();
        }*/
   
    public static void lettura_XML(String filename, double soglia) throws SAXException, IOException, ParserConfigurationException
    {
        int i,j;
        String id = "";
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(filename);
        
        // estrazione degli elementi "veicolo" dal documento
        NodeList veicoloNL = document.getElementsByTagName("veicolo");
        
        for(i = 0; i < veicoloNL.getLength(); i++)
        {
            Node veicolo_node = veicoloNL.item(i);
            if(veicolo_node.getNodeType() == Node.ELEMENT_NODE)
            {
                //estrazione elementi "ID" e "misura"
                Element veicolo_element = (Element) veicolo_node;
                id = veicolo_element.getElementsByTagName("ID").item(0).getTextContent();
                NodeList misuraNL = veicolo_element.getElementsByTagName("misura");
                boolean flag = true;
                
                //lista per i timestamp in cui la temperatura è maggiore della soglia
                List<Long> lista_timestamp;
                lista_timestamp = new ArrayList<Long>();
                
                for(j = 0; j < misuraNL.getLength(); j++)
                {
                    Node misura_node = misuraNL.item(j);
                    if(misura_node.getNodeType() == Node.ELEMENT_NODE)
                    {
                        // estrazione di "temperatura" e di "data_ora" dall'elemento "misura"
                        Element misura_element = (Element) misura_node;
                        double temperatura = Double.parseDouble(misura_element.getElementsByTagName("temperatura").item(0).getTextContent());
                        String data_ora = misura_element.getElementsByTagName("data_ora").item(0).getTextContent();
                        
                        if(temperatura >= soglia)
                        {
                            flag = false;
                            LocalDateTime date = LocalDateTime.parse(data_ora);
                            long timestamp = date.toEpochSecond(ZoneOffset.UTC);
                            lista_timestamp.add(timestamp);
                        }
                    }
                }
                
                if(flag)
                    System.out.println("Il veicolo ID: " + id + " HA tutte le temperature sotto la soglia (" + soglia + ").");
                else
                {
                    System.out.println("Il veicolo ID: " + id + " NON HA tutte le temperature sotto la soglia (" + soglia + ").");
                    System.out.println("Elenco dei timestamp nei quali la temperatura è maggiore di " + soglia + ":\t" + lista_timestamp);
                }
                   
                
            }
        }
        
    }
    
    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException 
    {
        Scanner input = new Scanner(System.in);
        double soglia;
        
        System.out.println("Inserisci la temperatura di soglia: ");
        soglia = input.nextDouble();
        lettura_XML("veicoli.xml", soglia);
    }
    
    
}
